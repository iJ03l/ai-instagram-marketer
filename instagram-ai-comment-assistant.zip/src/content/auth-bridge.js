// auth-bridge.js - Runs on Dashboard pages
// Acts as the messenger between website and extension background

console.log('[Crixen Auth Bridge] Loaded');

// Tell the website the extension is ready
window.postMessage({
    type: 'CRIXEN_EXTENSION_READY',
    extensionId: chrome.runtime.id
}, '*');

// Listen for auth messages FROM the website
window.addEventListener('message', async (event) => {
    // Security: Only accept from same origin
    if (event.origin !== window.location.origin) return;

    const { type, payload } = event.data;

    switch (type) {
        case 'CRIXEN_AUTH_LOGIN':
            console.log('[Auth Bridge] Received login credentials');

            // Forward to extension background
            chrome.runtime.sendMessage({
                action: 'auth:login',
                token: payload.token,
                user: payload.user,
                expiresAt: payload.expiresAt
            }, (response) => {
                // Send confirmation back to website
                window.postMessage({
                    type: 'CRIXEN_AUTH_LOGIN_ACK',
                    success: response?.success || false,
                    error: chrome.runtime.lastError?.message
                }, '*');
            });
            break;

        case 'CRIXEN_AUTH_LOGOUT':
            console.log('[Auth Bridge] Received logout signal');

            chrome.runtime.sendMessage({
                action: 'auth:logout'
            }, (response) => {
                window.postMessage({
                    type: 'CRIXEN_AUTH_LOGOUT_ACK',
                    success: true
                }, '*');
            });
            break;

        case 'CRIXEN_AUTH_REFRESH':
            console.log('[Auth Bridge] Token refresh request');

            chrome.runtime.sendMessage({
                action: 'auth:refresh',
                token: payload.token,
                expiresAt: payload.expiresAt
            }, (response) => {
                window.postMessage({
                    type: 'CRIXEN_AUTH_REFRESH_ACK',
                    success: response?.success || false
                }, '*');
            });
            break;

        case 'CRIXEN_CHECK_EXTENSION':
            console.log('[Auth Bridge] Check request received');
            window.postMessage({
                type: 'CRIXEN_EXTENSION_READY',
                extensionId: chrome.runtime.id
            }, '*');
            break;
    }
});

// Periodically check if extension background is alive
let healthCheckInterval = setInterval(() => {
    try {
        if (!chrome.runtime?.id) {
            clearInterval(healthCheckInterval);
            return;
        }
        chrome.runtime.sendMessage({ action: 'ping' }, (response) => {
            if (chrome.runtime.lastError) {
                console.log('[Auth Bridge] Background connected but error:', chrome.runtime.lastError);
                // Don't stop check, background might be restarting
            }
        });
    } catch (e) {
        console.log('[Auth Bridge] Extension context invalidated');
        clearInterval(healthCheckInterval);
    }
}, 30000); // Every 30s
