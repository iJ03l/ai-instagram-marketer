import { CONFIG } from '../config.js';

// Instagram AI Comment Assistant - Background Service Worker
// All models powered by NEAR AI Cloud (cloud.near.ai)

const NEAR_AI_ENDPOINT = CONFIG.NEAR_AI_ENDPOINT;
const API_TIMEOUT = 60000;

const AI_MODELS = {
    'deepseek': {
        name: 'DeepSeek V3.1',
        model: 'deepseek-ai/DeepSeek-V3.1',
        description: '',
        vision: false
    },
    'openai': {
        name: 'OpenAI GPT-5.2',
        model: 'openai/gpt-5.2',
        description: '',
        vision: true
    },
    'claude': {
        name: 'Claude Sonnet 4.5',
        model: 'anthropic/claude-sonnet-4-5',
        description: '',
        vision: true
    }
};

const COMMENT_STYLES = {
    friendly: {
        name: 'Friendly',
        prompt: 'Generate a warm, supportive, friendly comment. Include 1-2 relevant emojis. Keep it genuine.'
    },
    professional: {
        name: 'Professional',
        prompt: 'Generate a polished, business-appropriate comment. Be thoughtful. Minimal emojis.'
    },
    casual: {
        name: 'Casual',
        prompt: 'Generate a relaxed, conversational comment like talking to a friend.'
    },
    playful: {
        name: 'Playful',
        prompt: 'Generate a fun, lighthearted, and playful comment. Be cheeky, use humor, and vibe with the post.'
    },
    'radically-honest': {
        name: 'Radically Honest',
        prompt: 'Generate a blunt, direct, and radically honest comment. No fluff. Call it like it is.'
    },
    supportive: {
        name: 'Supportive',
        prompt: 'Generate a deeply encouraging and supportive comment. Validate their win or struggle. Be a cheerleader.'
    },
    enthusiastic: {
        name: 'Enthusiastic',
        prompt: 'Generate an energetic, excited comment! Show enthusiasm. Use emojis!'
    },
    witty: {
        name: 'Witty',
        prompt: 'Generate a clever, witty comment with subtle humor. Be smart but not mean.'
    }
};

// Initialize
chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['settings', 'stats'], (result) => {
        if (!result.settings) {
            chrome.storage.local.set({
                settings: {
                    selectedModel: 'deepseek',
                    apiKey: '',
                    defaultStyle: 'friendly',
                    customPrompt: ''
                }
            });
        }
        if (!result.stats) {
            chrome.storage.local.set({
                stats: {
                    generated: 0,
                    posted: 0,
                    byStyle: {}
                }
            });
        }
    });
});

// Message handler
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    (async () => {
        try {
            switch (request.action) {
                case 'auth:login':
                    await handleLogin(request.token, request.user, request.expiresAt);
                    sendResponse({ success: true });
                    break;

                case 'auth:logout':
                    await handleLogout();
                    sendResponse({ success: true });
                    break;

                case 'auth:refresh':
                    await handleTokenRefresh(request.token, request.expiresAt);
                    sendResponse({ success: true });
                    break;

                case 'ping':
                    sendResponse({ alive: true });
                    break;

                case 'auth:getStatus':
                    const status = await getAuthStatus();
                    sendResponse(status);
                    break;

                case 'generateComment':
                    const comment = await generateComment(
                        request.postContent,
                        request.style,
                        request.customPrompt,
                        request.imageUrls
                    );
                    sendResponse({ success: true, comment });
                    sendResponse({ success: true, comment });
                    break;

                case 'generatePost':
                    const postContent = await generatePost(request.topic);
                    sendResponse({ success: true, comment: postContent });
                    break;

                case 'getSettings':
                    const settings = await getSettings();
                    sendResponse({ settings, models: AI_MODELS, styles: COMMENT_STYLES });
                    break;

                case 'saveSettings':
                    await chrome.storage.local.set({ settings: request.settings });
                    sendResponse({ success: true });
                    break;

                case 'getStats':
                    const stats = await getStats();
                    sendResponse({ stats });
                    break;

                case 'updateStats':
                    await updateStats(request.statType, request.style);
                    sendResponse({ success: true });
                    break;

                case 'testConnection':
                    const testResult = await testApiConnection(request.apiKey);
                    sendResponse(testResult);
                    break;

                case 'saveStrategies':
                    await updateStrategies(request.strategies);
                    sendResponse({ success: true });
                    break;

                // --- NOTION GENERATORS ---

                case 'generateStrategyDoc':
                    const strategyDoc = await generateStrategyDoc(request.additionalContext);
                    sendResponse({ success: true, doc: strategyDoc });
                    break;

                case 'generateSmartReport':
                    const reportDoc = await generateSmartReport(request.stats);
                    sendResponse({ success: true, doc: reportDoc });
                    break;

                case 'generateToolkit':
                    const toolkitDoc = await generateToolkitDoc(request.toolType, request.additionalContext);
                    sendResponse({ success: true, doc: toolkitDoc });
                    break;

                // Legacy sync (cleanup if needed, but keeping primarily new auth)
                case 'loginSync':
                    console.warn('[Background] Legacy loginSync called. Prefer auth:login.');
                    if (request.token) {
                        await handleLogin(request.token, request.user);
                        sendResponse({ success: true });
                    } else {
                        sendResponse({ success: false, error: 'No token' });
                    }
                    break;

                default:
                    sendResponse({ error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background error:', error);
            sendResponse({ success: false, error: error.message });
        }
    })();
    return true;
});

// ===== AUTH HANDLERS =====

async function handleLogin(token, user, expiresAt) {
    console.log('[Auth] Login received for user:', user?.email);

    await chrome.storage.local.set({
        crixen_auth: {
            token: token,
            user: user,
            expiresAt: expiresAt || Date.now() + (7 * 24 * 60 * 60 * 1000), // 7 days default
            lastSync: Date.now()
        },
        // Backwards compatibility for other parts of extension reading 'token' directly
        token: token,
        activeProjectId: 'default' // Default for now
    });

    // Update badge to show logged-in state
    chrome.action.setBadgeText({ text: '✓' });
    chrome.action.setBadgeBackgroundColor({ color: '#10b981' }); // Green

    // Notify all tabs that auth changed
    broadcastAuthChange('login', user);

    console.log('[Auth] Login stored successfully');
}

async function handleLogout() {
    console.log('[Auth] Logout received');

    await chrome.storage.local.remove(['crixen_auth', 'token', 'activeProjectId']); // Remove legacy keys too

    // Update badge
    chrome.action.setBadgeText({ text: '' });

    // Notify all tabs
    broadcastAuthChange('logout', null);

    console.log('[Auth] Logout complete');
}

async function handleTokenRefresh(newToken, newExpiresAt) {
    console.log('[Auth] Token refresh');

    const { crixen_auth } = await chrome.storage.local.get('crixen_auth');

    if (crixen_auth) {
        crixen_auth.token = newToken;
        crixen_auth.expiresAt = newExpiresAt;
        crixen_auth.lastSync = Date.now();

        await chrome.storage.local.set({
            crixen_auth,
            token: newToken //Sync legacy key
        });
        console.log('[Auth] Token refreshed');
    }
}

async function getAuthStatus() {
    const { crixen_auth } = await chrome.storage.local.get('crixen_auth');

    if (!crixen_auth) {
        return { authenticated: false };
    }

    // Check if token expired
    const isExpired = crixen_auth.expiresAt < Date.now();

    return {
        authenticated: !isExpired,
        user: crixen_auth.user,
        expiresAt: crixen_auth.expiresAt,
        needsRefresh: (crixen_auth.expiresAt - Date.now()) < (24 * 60 * 60 * 1000) // < 24h left
    };
}

// Broadcast auth changes to all tabs
function broadcastAuthChange(type, user) {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, {
                type: 'CRIXEN_AUTH_CHANGED',
                authType: type,
                user: user
            }).catch(() => {
                // Tab might not have content script, ignore
            });
        });
    });
}

// Auto token refresh check (every 5 minutes)
chrome.alarms.create('tokenRefreshCheck', { periodInMinutes: 5 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'tokenRefreshCheck') {
        const status = await getAuthStatus();

        if (status.authenticated && status.needsRefresh) {
            console.log('[Auth] Token expiring soon, requesting refresh from dashboard');

            // Find dashboard tab and request refresh
            const tabs = await chrome.tabs.query({
                url: [
                    'https://crixen.xyz/*',
                    'https://www.crixen.xyz/*',
                    'http://localhost:5173/*',
                    'http://127.0.0.1:5173/*'
                ]
            });

            if (tabs.length > 0) {
                chrome.tabs.sendMessage(tabs[0].id, {
                    type: 'CRIXEN_REQUEST_TOKEN_REFRESH'
                });
            }
        }
    }
});

async function getSettings() {
    return new Promise((resolve) => {
        chrome.storage.local.get('settings', (result) => {
            resolve(result.settings || {
                selectedModel: 'deepseek',
                apiKey: '',
                defaultStyle: 'friendly'
            });
        });
    });
}

async function getStats() {
    return new Promise((resolve) => {
        chrome.storage.local.get('stats', (result) => {
            resolve(result.stats || { generated: 0, posted: 0, byStyle: {} });
        });
    });
}

async function updateStats(statType, style) {
    const stats = await getStats();
    if (statType === 'generated') {
        stats.generated = (stats.generated || 0) + 1;
        if (style) {
            stats.byStyle = stats.byStyle || {};
            stats.byStyle[style] = (stats.byStyle[style] || 0) + 1;
        }
    } else if (statType === 'posted') {
        stats.posted = (stats.posted || 0) + 1;
    }
    await chrome.storage.local.set({ stats });
}

async function updateStrategies(newStrategies) {
    const settings = await getSettings();
    settings.capturedStrategies = newStrategies;
    await chrome.storage.local.set({ settings });
}

async function testApiConnection(apiKey) {
    const cleanedKey = apiKey ? apiKey.replace(/[<>\s]/g, '') : '';
    if (!cleanedKey) return { success: false, error: 'No API key provided' };

    try {
        const response = await fetch(NEAR_AI_ENDPOINT, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${cleanedKey}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'deepseek-ai/DeepSeek-V3.1',
                messages: [{ role: 'user', content: 'Say OK' }],
                max_tokens: 5
            })
        });

        if (response.ok) return { success: true, message: 'API connection successful!' };

        const text = await response.text();
        return { success: false, error: `API Error: ${response.status} - ${text}` };
    } catch (error) {
        return { success: false, error: error.message };
    }
}

// --- CORE GENERATION LOGIC ---

async function fetchWithTimeout(url, options, timeout = API_TIMEOUT) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);
    try {
        const response = await fetch(url, { ...options, signal: controller.signal });
        clearTimeout(timeoutId);
        return response;
    } catch (error) {
        clearTimeout(timeoutId);
        throw error;
    }
}

async function generateComment(postContent, style, customPrompt = '', imageUrls = []) {
    const settings = await getSettings();
    let modelKey = settings.selectedModel || 'deepseek';
    if (!AI_MODELS[modelKey]) {
        console.warn(`[generateComment] Invalid model '${modelKey}' selected. Falling back to 'deepseek'.`);
        modelKey = 'deepseek';
    }

    const modelConfig = AI_MODELS[modelKey];
    // Optional apiKey for direct mode (if used)
    const apiKey = settings.apiKey ? settings.apiKey.replace(/[<>\s]/g, '') : '';

    const stylePrompt = style === 'custom' && customPrompt
        ? customPrompt
        : (style.startsWith('custom:')
            ? ((settings.capturedStrategies || []).find(s => s.name === style.split(':')[1])?.prompt || COMMENT_STYLES.friendly.prompt)
            : COMMENT_STYLES[style]?.prompt || COMMENT_STYLES.friendly.prompt);

    const globalInstructions = settings.instructions ? `\nInstructions: ${settings.instructions}` : '';

    const systemPrompt = `You are an expert social media commenter.
Rules:
1. **Strict Context:** Respond ONLY to the specific content of the post. Never be generic.
2. **Formatting:** Use proper paragraphs. No em dashes '—'.
3. **Spacing:** EXTREMELY IMPORTANT: Use DOUBLE LINE BREAKS between every sentence or thought. The text must look vertically spaced out.
4. **Style:** ${stylePrompt}${globalInstructions}
5. **Persona:** Share thoughts aligned with instructions. Do NOT be a reply bot. Be extremely smart, thoughtful, and high-value.
6. **Emojis:** Max 3 relevant emojis.`;

    let userMessageContent;
    if (modelConfig.vision && imageUrls && imageUrls.length > 0) {
        userMessageContent = [
            { type: 'text', text: `Context:\n${postContent}` },
            ...imageUrls.map(url => ({ type: 'image_url', image_url: { url, detail: 'auto' } }))
        ];
    } else {
        userMessageContent = `Context:\n${postContent}`;
    }

    /* 
    Old payload construction removed
    const payload = {
        model: modelConfig.model,
        messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: userMessageContent }
        ],
        max_tokens: 200,
        temperature: 0.8
    }; 
    */



    // Use Crixen API (SaaS Proxy)
    const CRIXEN_API_URL = CONFIG.API_URL;

    // Get Auth Token & Active Project
    const { token, activeProjectId } = await new Promise(resolve =>
        chrome.storage.local.get(['token', 'activeProjectId'], resolve)
    );

    if (!token) {
        console.error('No auth token found. Please login.');
        return { error: 'AUTH_REQUIRED' };
    }

    const projectId = activeProjectId || 'default';

    const payload = {
        projectId,
        prompt: systemPrompt,
        context: postContent
    };

    console.log('[generateComment] Calling Crixen API:', JSON.stringify(payload));

    const response = await fetchWithTimeout(CRIXEN_API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
    });

    if (response.status === 401) {
        return { error: 'AUTH_REQUIRED' };
    }

    if (!response.ok) {
        let errorMessage;
        try {
            const errorData = await response.json();
            errorMessage = errorData.error || await response.text();
        } catch (e) {
            errorMessage = await response.text();
        }
        throw new Error(errorMessage);
    }

    const data = await response.json();

    // Fix: Crixen Proxy API returns { content, meta } structure
    // The previous code expected raw OpenAI format (data.choices[0].message.content)
    let content = data.content || data.choices?.[0]?.message?.content || 'No response';

    // Strict Post-Processing
    let cleaned = content.trim()
        .replace(/—/g, ' ')   // Em dash
        .replace(/–/g, ' ')   // En dash
        .replace(/--/g, ' '); // Double hyphen

    // Force Double Spacing: Convert any sequence of newlines to exactly two
    cleaned = cleaned.replace(/\r\n/g, '\n').replace(/\n+/g, '\n\n');

    return cleaned;
}

async function generatePost(topic) {
    const settings = await getSettings();

    // Auth Check
    const { token, activeProjectId } = await new Promise(resolve =>
        chrome.storage.local.get(['token', 'activeProjectId'], resolve)
    );

    if (!token) return { error: 'AUTH_REQUIRED' };

    const projectId = activeProjectId || 'default';
    const globalInstructions = settings.instructions ? `\nInstructions: ${settings.instructions}` : '';

    // Resolve Style/Strategy
    const style = settings.defaultStyle || 'professional';
    const customPrompt = settings.customPrompt || '';

    // Logic to find prompt based on style key (similar to generateComment)
    const stylePrompt = style === 'custom' && customPrompt
        ? customPrompt
        : (style.startsWith('custom:')
            ? ((settings.capturedStrategies || []).find(s => s.name === style.split(':')[1])?.prompt || COMMENT_STYLES.professional.prompt)
            : COMMENT_STYLES[style]?.prompt || COMMENT_STYLES.professional.prompt);

    // Create System Prompt for Posts
    const systemPrompt = `You are an expert ghostwriter for social media.
Rules:
1. **Goal:** Write a high-impact, engaging Tweet/Post ABOUT the user's input topic.
2. **Context:** The user input is a TOPIC or VIBE. Do NOT reply to the user. Write the post itself as if you are them.
3. **Formatting:** Use proper paragraphs. No em dashes '—'.
4. **Spacing:** EXTREMELY IMPORTANT: Use DOUBLE LINE BREAKS between every sentence or thought. The text must look vertically spaced out.
5. **Style:** ${stylePrompt}${globalInstructions}
6. **Persona:** Share thoughts aligned with instructions. Do NOT be a reply bot.
7. **Constraints:** Under 280 characters.
8. **Emojis:** Max 2 relevant emojis.`;

    const payload = {
        projectId,
        prompt: systemPrompt,
        context: topic // The user's input topic
    };

    console.log('[generatePost] Calling Crixen API:', JSON.stringify(payload));

    // Use same Crixen API (SaaS Proxy)
    const CRIXEN_API_URL = CONFIG.API_URL;

    const response = await fetchWithTimeout(CRIXEN_API_URL, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(payload)
    });

    if (response.status === 401) {
        return { error: 'AUTH_REQUIRED' };
    }

    if (!response.ok) {
        const err = await response.text();
        throw new Error(`AI Error ${response.status}: ${err}`);
    }

    const data = await response.json();

    let content = data.content || data.choices?.[0]?.message?.content || 'No response';

    // Strict Post-Processing
    // Strict Post-Processing
    let cleaned = content.trim()
        .replace(/—/g, ' ')   // Em dash
        .replace(/–/g, ' ')   // En dash
        .replace(/--/g, ' '); // Double hyphen

    // Force Double Spacing
    cleaned = cleaned.replace(/\r\n/g, '\n').replace(/\n+/g, '\n\n');

    return cleaned;
}

// --- GENERIC CALLER FOR NOTION TOOLS ---

async function callNearAI(prompt, maxTokens = null) {
    const settings = await getSettings();
    // Map simple key to full model ID
    const modelKey = settings.selectedModel || 'deepseek';
    const modelID = AI_MODELS[modelKey]?.model || 'deepseek-ai/DeepSeek-V3.1';

    // Fallback cleanup if user data has old V3 string
    // This is less likely with new keys, but safe to keep logic simple

    const apiKey = settings.apiKey ? settings.apiKey.replace(/[<>\s]/g, '') : '';
    if (!apiKey) throw new Error('No API key');

    // STRICT MINIMAL PAYLOAD for Strategy/Report
    const payload = {
        model: modelID,
        messages: [{ role: 'user', content: prompt }]
    };

    if (maxTokens) payload.max_tokens = maxTokens;

    console.log('[callNearAI] Request:', JSON.stringify(payload));

    const response = await fetchWithTimeout(NEAR_AI_ENDPOINT, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    });

    if (!response.ok) {
        const err = await response.text();
        throw new Error(`AI API Error: ${response.status} - ${err}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content?.trim();
    if (!content) throw new Error('Empty AI response');
    return content.replace(/^["']|["']$/g, '').trim(); // Clean quotes
}

// --- NOTION GENERATORS ---

async function generateStrategyDoc(inputs = {}) {
    // Robustly handle string or object input for backward compatibility
    let context = '';
    if (typeof inputs === 'string') {
        context = inputs;
    } else {
        context = `
    - Brand Name: ${inputs.brandName || 'Not specified'}
    - Industry: ${inputs.industry || 'Not specified'}
    - Target Audience: ${inputs.targetAudience || 'Not specified'}
    - Main Goals: ${inputs.goals || 'Not specified'}
    - Platforms: ${inputs.platforms || 'Not specified'}
    - Brand Voice: ${inputs.brandVoice || 'Professional'}
    - Unique Value: ${inputs.uniqueValue || 'Not specified'}
        `.trim();
    }

    return callNearAI(
        `You are a world-class Social Media Strategist.
Create an extremely detailed, high-end Brand Social Media Strategy document in Markdown.

USER CONTEXT:
${context}

Include:
1. Executive Summary
2. Brand Pillars (3 themes)
3. Tone of Voice
4. Target Audience Persona
5. Content Mix Table
6. Growth Tactics
Output ONLY markdown.`,
        2500 // Max tokens
    );
}

async function generateSmartReport(stats) {
    return callNearAI(
        `You are a professional Social Media Manager.
Analyze daily metrics and provide a professional summary in Markdown.
Metrics:
- Generated: ${stats.generated || 0}
- Posted: ${stats.posted || 0}
- Styles: ${JSON.stringify(stats.byStyle || {})}
Output Title, Executive Summary, Metrics Table, Insights.
Output ONLY markdown.`,
        1500
    );
}

async function generateToolkitDoc(type, inputs = {}) {
    // Handle Context from inputs object
    let context = '';
    let emailGoal = 'General Outreach';

    if (typeof inputs === 'string') {
        context = inputs;
    } else if (type === 'calendar') {
        context = `
    - Brand: ${inputs.brandName}
    - Industry: ${inputs.industry}
    - Content Themes: ${inputs.themes}
    - Posting Frequency: ${inputs.frequency}
    - Content Types: ${inputs.contentTypes}
    - Current Campaign: ${inputs.campaign || 'General'}
        `.trim();
    } else if (type === 'audit') {
        context = `
    - Brand: ${inputs.brandName}
    - Industry: ${inputs.industry}
    - Competitors: ${inputs.competitors}
    - Platforms to Analyze: ${inputs.platforms}
    - Focus Metrics: ${inputs.metrics}
    - Current Strength: ${inputs.strength || 'Unknown'}
        `.trim();
    } else if (type === 'influencer') {
        context = `
    - Industry: ${inputs.industry}
    - Campaign Goal: ${inputs.goal}
    - Budget: ${inputs.budget}
    - Influencer Tier: ${inputs.tier}
    - Platforms: ${inputs.platforms}
    - Deliverables: ${inputs.deliverables || 'Standard'}
    - Timeline: ${inputs.timeline || 'ASAP'}
        `.trim();
        emailGoal = inputs.goal;
    }

    const prompts = {
        calendar: `You are an expert Social Media Manager.
Create a 4-Week Social Media Content Calendar Template in Markdown based on the user's specific needs.

USER CONTEXT:
${context}

Table columns: [Week], [Theme], [Post Type], [Caption Idea], [Status].
Ensure the content matches their industry (${inputs.industry || 'General'}) and frequency (${inputs.frequency || 'Daily'}).
Output ONLY markdown.`,

        audit: `You are an expert Social Media Manager.
Create a Competitor Audit Report in Markdown.

USER CONTEXT:
${context}

Sections: 
1. Audit of the specific competitors mentioned.
2. SWOT Analysis for ${inputs.brandName || 'the brand'}.
3. Content Gap Analysis vs competitors.
4. Action Plan to beat the metric: ${inputs.metrics || 'Engagement'}.
Output ONLY markdown.`,

        influencer: `You are an expert Social Media Manager.
Create an Influencer Outreach Tracker & Plan in Markdown.

USER CONTEXT:
${context}

Table columns: [Name], [Niche], [Platform], [Follower Count], [Status], [Notes].
Include 3 tailored Outreach Email Templates based on their campaign goal: ${emailGoal}.
Output ONLY markdown.`
    };

    if (!prompts[type]) throw new Error('Invalid Tool');
    return callNearAI(prompts[type], 2500);
}