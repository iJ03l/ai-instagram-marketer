// Crixen - Twitter Utilities (Prod Grade)

(() => {
    'use strict';

    window.CrixenTwitter = window.CrixenTwitter || {};
    const utils = window.CrixenTwitter;

    utils.state = utils.state || {
        currentTweet: null,
        settings: null,
        isProcessing: false,

        // autopilot
        isAutoPilot: false,
        autoLimit: 20,
        autoCount: 0,
        autoPhase: 'idle',
        autoAbortController: null,

        // internal
        lastInjectAt: 0
    };

    const state = utils.state;

    utils.isExtensionValid = function () {
        try {
            chrome.runtime.id;
            return true;
        } catch {
            return false;
        }
    };

    utils.loadSettings = async function () {
        if (!utils.isExtensionValid()) return;
        return new Promise((resolve) => {
            try {
                chrome.runtime.sendMessage({ action: 'getSettings' }, (response) => {
                    if (chrome.runtime.lastError) return resolve();
                    state.settings = response?.settings || { defaultStyle: 'witty', customPrompt: '' };
                    resolve();
                });
            } catch {
                resolve();
            }
        });
    };

    utils.sleep = (ms) => new Promise((r) => setTimeout(r, ms));

    utils.isElementVisible = function (el) {
        if (!el) return false;
        const rect = el.getBoundingClientRect();
        if (rect.width < 2 || rect.height < 2) return false;
        if (rect.bottom < 0 || rect.top > window.innerHeight) return false;
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
        return true;
    };

    utils.showToast = function (message, type = 'info') {
        document.querySelectorAll('.crixen-toast-message').forEach((el) => el.remove());

        const toast = document.createElement('div');
        toast.className = 'crixen-toast-message';
        toast.textContent = message;

        const bg =
            type === 'error' ? '#ff3b30' :
                type === 'success' ? '#34c759' :
                    type === 'warning' ? '#ff9f0a' : '#1d9bf0';

        Object.assign(toast.style, {
            position: 'fixed',
            bottom: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: bg,
            color: 'white',
            padding: '12px 18px',
            borderRadius: '999px',
            zIndex: '2147483647',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            fontSize: '14px',
            fontWeight: '800',
            boxShadow: '0 8px 20px rgba(0,0,0,0.18)',
            opacity: '0',
            transition: 'all 220ms ease'
        });

        document.body.appendChild(toast);

        requestAnimationFrame(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(-50%) translateY(-10px)';
        });

        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(-50%) translateY(14px)';
            setTimeout(() => toast.remove(), 240);
        }, 3500);
    };

    utils.showAuthPrompt = function () {
        document.querySelectorAll('.crixen-auth-prompt').forEach((el) => el.remove());

        const toast = document.createElement('div');
        toast.className = 'crixen-auth-prompt';
        toast.innerHTML = `
      <div style="display:flex;align-items:center;gap:12px;">
        <span style="font-weight:800;">Login required to use Crixen</span>
        <button id="crixen-twitter-login-btn" style="
          background:white;color:#1d9bf0;border:none;padding:6px 12px;border-radius:12px;
          font-weight:900;cursor:pointer;font-size:13px;
        ">Login</button>
      </div>
    `;

        Object.assign(toast.style, {
            position: 'fixed',
            bottom: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: '#1d9bf0',
            color: 'white',
            padding: '12px 16px',
            borderRadius: '999px',
            zIndex: '2147483647',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            fontSize: '14px',
            fontWeight: '700',
            boxShadow: '0 8px 20px rgba(0,0,0,0.22)'
        });

        document.body.appendChild(toast);

        toast.querySelector('#crixen-twitter-login-btn')?.addEventListener('click', () => {
            window.open('https://crixen.xyz', '_blank');
            toast.remove();
        });

        setTimeout(() => toast.remove(), 9000);
    };

    // Pick best visible tweet for autopilot
    utils.pickBestVisibleTweet = function () {
        const tweets = Array.from(document.querySelectorAll('article[data-testid="tweet"]'));
        const scored = [];

        for (const t of tweets) {
            if (!utils.isElementVisible(t)) continue;
            if (t.dataset.crixenAutopilot === 'done') continue;
            if (t.dataset.crixenAutopilot === 'skipped') continue;

            // Skip ads/promos
            if (/ad/i.test(t.innerText) && /promoted/i.test(t.innerText)) {
                t.dataset.crixenAutopilot = 'skipped';
                continue;
            }

            const r = t.getBoundingClientRect();
            const centerDist = Math.abs((r.top + r.bottom) / 2 - window.innerHeight / 2);
            scored.push({ t, score: centerDist });
        }

        scored.sort((a, b) => a.score - b.score);
        return scored[0]?.t || null;
    };

})();