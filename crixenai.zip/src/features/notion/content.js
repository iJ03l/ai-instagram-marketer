// Crixen - Notion Integration (Prod Grade Native UI Injection)

(() => {
    'use strict';

    const Logger = window.CrixenLogger || console;

    const EXT = {
        containerId: 'crixen-ai-controls',
        debounceMs: 400,
        injectCooldownMs: 2500,
        lastInjectAt: 0
    };

    Logger.info('[CRIXEN][Notion] Script loaded');

    // ---------------------------
    // Mutation observer (debounced + cooldown)
    // ---------------------------

    let debounceTimeout = null;

    const observer = new MutationObserver(() => {
        if (debounceTimeout) clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            try {
                handleInjection();
            } catch (e) {
                Logger.warn('[CRIXEN][Notion] injection error', e);
            }
        }, EXT.debounceMs);
    });

    observer.observe(document.body, { childList: true, subtree: true });

    // Initial attempt
    handleInjection();

    function handleInjection() {
        const now = Date.now();
        if (now - EXT.lastInjectAt < EXT.injectCooldownMs) return;
        EXT.lastInjectAt = now;

        addCustomButtons();
    }

    // ---------------------------
    // Icons
    // ---------------------------

    const ICONS = {
        strategy: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></svg>`,
        calendar: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
        audit: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
        influencer: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>`,
        capture: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`,
        report: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`
    };

    // ---------------------------
    // Injection: topbar target selection (safer)
    // ---------------------------

    function findTopbarActionsContainer() {
        const topbar = document.querySelector('.notion-topbar');
        if (!topbar) return null;

        // Prefer the right-side region
        // Notion changes DOM often; we use a few heuristics
        const candidates = [
            topbar.querySelector('div[style*="display: flex"][style*="justify-content: space-between"]'),
            topbar.querySelector('div[style*="display: flex"]'),
            topbar.lastElementChild
        ].filter(Boolean);

        // Find a container that has buttons inside
        for (const c of candidates) {
            const hasButtons = c.querySelector('div[role="button"], button, a');
            if (hasButtons) return c;
        }
        return candidates[0] || null;
    }

    function analyzeContext() {
        const pageContent = document.querySelector('.notion-page-content');
        if (!pageContent) return { type: 'none' };

        const blocks = pageContent.querySelectorAll('[data-block-id]');
        if (blocks.length < 2) return { type: 'empty' };

        return { type: 'page' };
    }

    function addCustomButtons() {
        const actionsContainer = findTopbarActionsContainer();
        if (!actionsContainer) return;

        // If exists already, ensure it still attached
        if (document.getElementById(EXT.containerId)) return;

        const context = analyzeContext();
        if (context.type === 'none') return;

        const container = document.createElement('div');
        container.id = EXT.containerId;
        Object.assign(container.style, {
            display: 'flex',
            alignItems: 'center',
            gap: '4px',
            marginRight: '12px'
        });

        // Strategy
        container.appendChild(
            createButton(
                'Strategy',
                async () => {
                    const questions = [
                        { id: 'brandName', label: 'Brand/Business Name', type: 'text', required: true },
                        { id: 'industry', label: 'Industry/Niche', type: 'text', required: true },
                        { id: 'audience_mission', label: 'Target Audience, Mission', type: 'textarea', required: true },
                        { id: 'brandVoice', label: 'Brand Voice/Tone', type: 'text' },
                        { id: 'usp', label: 'Unique Selling Point', type: 'textarea' }
                    ];
                    const answers = await createInputModal('Brand Strategy Builder', questions, ICONS.strategy);
                    if (answers) await generateAndInsertContent('generateStrategyDoc', 'Strategy', null, true, answers);
                },
                ICONS.strategy,
                'secondary',
                'Generate a full brand strategy document'
            )
        );

        // Calendar
        container.appendChild(
            createButton(
                'Calendar',
                async () => {
                    const questions = [
                        { id: 'brandName', label: 'Brand/Business Name', type: 'text', required: true },
                        { id: 'description', label: 'Description', type: 'textarea' },
                        { id: 'industry', label: 'Industry', type: 'text', required: true },
                        { id: 'frequency', label: 'Posts per Week', type: 'select', options: ['3', '5', '7', '10+'], required: true }
                    ];
                    const answers = await createInputModal('Content Calendar Setup', questions, ICONS.calendar);
                    if (answers) await generateAndInsertContent('generateToolkit', 'Content Calendar', 'calendar', true, answers);
                },
                ICONS.calendar,
                'secondary',
                'Create a social media content calendar'
            )
        );

        // Audit
        container.appendChild(
            createButton(
                'Audit',
                async () => {
                    const questions = [
                        { id: 'brandName', label: 'Your Brand Name', type: 'text', required: true },
                        { id: 'industry', label: 'Industry', type: 'text', required: true },
                        { id: 'description', label: 'Description', type: 'textarea' },
                        { id: 'analyze_what', label: 'What to analyze?', type: 'multiselect', options: ['Content Strategy', 'Engagement', 'Visuals', 'Hashtags', 'Competitors'], required: true },
                        { id: 'strength', label: 'Your Current Strength', type: 'text' }
                    ];
                    const answers = await createInputModal('Competitor Audit Setup', questions, ICONS.audit);
                    if (answers) await generateAndInsertContent('generateToolkit', 'Competitor Audit', 'audit', true, answers);
                },
                ICONS.audit,
                'secondary',
                'Generate a competitor analysis report'
            )
        );

        // Influencer
        container.appendChild(
            createButton(
                'Influencer',
                async () => {
                    const questions = [
                        { id: 'goal', label: 'Campaign Goal', type: 'select', options: ['Brand Awareness', 'Sales/Conversions', 'UGC Creation', 'Event Promotion'], required: true },
                        { id: 'industry', label: 'Industry/Niche', type: 'text', required: true },
                        { id: 'budget', label: 'Budget Range', type: 'select', options: ['$0-$500', '$500-$2000', '$2000-$10k', '$10k+'], required: true },
                        { id: 'platforms', label: 'Target Platforms', type: 'multiselect', options: ['Instagram', 'TikTok', 'YouTube', 'X/Twitter', 'LinkedIn'], required: true },
                        { id: 'deliverables', label: 'Expected Deliverables', type: 'textarea' },
                        { id: 'timeline', label: 'Campaign Timeline', type: 'text' }
                    ];
                    const answers = await createInputModal('Influencer Campaign Setup', questions, ICONS.influencer);
                    if (answers) await generateAndInsertContent('generateToolkit', 'Influencer Tracker', 'influencer', true, answers);
                },
                ICONS.influencer,
                'secondary',
                'Create an influencer tracking database'
            )
        );

        // Capture (primary)
        container.appendChild(
            createButton(
                'Capture',
                async () => {
                    const strategies = await scrapeStrategies();
                    if (strategies.length > 0) {
                        await chrome.runtime.sendMessage({ action: 'saveStrategies', strategies });
                        showToast(`Captured ${strategies.length} strategies`, 'success');
                    } else {
                        showToast('No structured data found (Need Name & Prompt)', 'error');
                    }
                },
                ICONS.capture,
                'primary',
                'Capture strategies from selection or page'
            )
        );

        // Report (industry-grade)
        container.appendChild(
            createButton(
                'Report',
                async () => {
                    showToast('Building report...', 'info');

                    const statsRes = await chrome.runtime.sendMessage({ action: 'getStats' }).catch(() => null);
                    if (!statsRes?.stats) {
                        if (statsRes?.code === 'AUTH_REQUIRED' || statsRes?.error === 'AUTH_REQUIRED') showAuthPrompt();
                        else showToast('Could not read stats', 'error');
                        return;
                    }

                    const stats = statsRes.stats || {};
                    const reportMd = await buildIndustryDailyReport(stats);

                    // Append report without clearing the page
                    const ok = await insertContentIntoNotion(reportMd, false);
                    showToast(ok ? 'Report appended' : 'Could not insert report', ok ? 'success' : 'error');
                },
                ICONS.report,
                'secondary',
                'Append an industry-grade daily report'
            )
        );

        actionsContainer.prepend(container);
    }

    // ---------------------------
    // Generation: unified call to background
    // ---------------------------

    async function generateAndInsertContent(action, displayName, toolType = null, clearPage = false, additionalContext = null) {
        showToast(`Generating ${displayName}...`, 'info');

        try {
            const message = { action, additionalContext };
            if (toolType) message.toolType = toolType;

            const res = await chrome.runtime.sendMessage(message);

            if (res && res.success && res.doc) {
                const ok = await insertContentIntoNotion(res.doc, clearPage);
                showToast(ok ? `${displayName} created` : 'Could not insert content', ok ? 'success' : 'error');
                return;
            }

            if (res?.code === 'AUTH_REQUIRED' || res?.error === 'AUTH_REQUIRED') {
                showAuthPrompt();
                return;
            }

            showToast(`Generation failed: ${res?.error || 'Unknown error'}`, 'error');
        } catch (e) {
            Logger.error('[CRIXEN][Notion] generateAndInsert error', e);
            showToast(`Error: ${e?.message || String(e)}`, 'error');
        }
    }

    // ---------------------------
    // Industry-grade report generator (better than old pushReport)
    // - stores daily snapshots locally for deltas
    // ---------------------------

    async function buildIndustryDailyReport(stats) {
        const now = new Date();
        const dayKey = now.toISOString().slice(0, 10); // YYYY-MM-DD
        const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

        const generated = Number(stats.generated || 0);
        const posted = Number(stats.posted || 0);
        const byStyle = stats.byStyle && typeof stats.byStyle === 'object' ? stats.byStyle : {};
        const topStyles = Object.entries(byStyle).sort((a, b) => (b[1] || 0) - (a[1] || 0)).slice(0, 5);

        // Load history baseline
        const history = await storageGet('crixen_report_history').then((r) => r?.crixen_report_history || {});
        const yesterdayKey = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
        const yesterday = history[yesterdayKey] || null;

        const genDelta = yesterday ? generated - Number(yesterday.generated || 0) : null;
        const postDelta = yesterday ? posted - Number(yesterday.posted || 0) : null;

        // ratios
        const publishRate = generated > 0 ? Math.round((posted / generated) * 100) : 0;

        // Write today snapshot back (so future reports can delta)
        history[dayKey] = { generated, posted, byStyle, at: now.toISOString() };
        await storageSet({ crixen_report_history: trimHistory(history, 35) });

        // Recommendations (simple but useful heuristics)
        const recs = [];
        if (generated === 0) recs.push('Generate at least 5 drafts before posting to keep quality high.');
        if (generated > 0 && publishRate < 30) recs.push('Posting rate is low. Consider posting the top 20% drafts and discarding the rest.');
        if (posted > 0 && topStyles.length) recs.push(`Double down on "${topStyles[0][0]}" this week; it’s your highest-volume style.`);
        if (posted === 0 && generated > 0) recs.push('You generated drafts but posted none. Schedule 10 minutes to publish 1–2 today.');

        // Markdown report (Notion-friendly)
        const md = `# Daily Social Output Report

**Date:** ${dayKey}  
**Time:** ${time}

---

## KPI Snapshot

| Metric | Today | Δ vs Yesterday |
|---|---:|---:|
| Drafts Generated | ${generated} | ${fmtDelta(genDelta)} |
| Posts/Comments Published | ${posted} | ${fmtDelta(postDelta)} |
| Publish Rate | ${publishRate}% | ${yesterday ? fmtDelta(publishRate - (Number(yesterday.generated || 0) ? Math.round((Number(yesterday.posted || 0) / Number(yesterday.generated || 0)) * 100) : 0)) : '—'} |

---

## Style Mix (Top)

${topStyles.length ? topStyles.map(([s, c]) => `- **${escapeMd(s)}**: ${c}`).join('\n') : '_No style data yet._'}

---

## Notes & Insights

- Primary focus today: ${posted > 0 ? 'Execution (publishing)' : 'Pipeline (drafting)'}  
- Consistency check: ${posted >= 3 ? 'Good daily shipping cadence.' : 'Aim for 1–3 meaningful publishes/day to build momentum.'}

---

## Recommendations (Next 24h)

${recs.length ? recs.map((r) => `- ${r}`).join('\n') : '- Keep doing what you’re doing. Maintain cadence and keep quality strict.'}

---

## Raw Counters (Debug)

- generated: ${generated}
- posted: ${posted}
- byStyle: ${escapeMd(JSON.stringify(byStyle))}
`;

        return md;
    }

    function fmtDelta(n) {
        if (n === null || typeof n !== 'number' || Number.isNaN(n)) return '—';
        if (n === 0) return '0';
        return n > 0 ? `+${n}` : `${n}`;
    }

    function trimHistory(history, maxDays) {
        const keys = Object.keys(history).sort(); // YYYY-MM-DD sort
        if (keys.length <= maxDays) return history;
        const toDrop = keys.slice(0, keys.length - maxDays);
        for (const k of toDrop) delete history[k];
        return history;
    }

    function escapeMd(s) {
        return String(s || '').replace(/[\\`*_{}[\]()#+\-.!|]/g, '\\$&');
    }

    // ---------------------------
    // Notion insertion (clipboard paste) - improved and safer
    // ---------------------------

    async function insertContentIntoNotion(markdownContent, clearPage = false) {
        if (!markdownContent || !String(markdownContent).trim()) return false;

        let target =
            document.querySelector('[data-content-editable-leaf="true"]') ||
            document.querySelector('.notion-page-content [contenteditable="true"]');

        if (!target) {
            Logger.error('[CRIXEN][Notion] No editable area found');
            return false;
        }

        target.click();
        await sleep(120);
        target.focus();
        await sleep(180);

        if (clearPage) {
            // Notion: selectAll + delete inside editor
            try {
                document.execCommand('selectAll', false, null);
                await sleep(80);
                document.execCommand('delete', false, null);
                await sleep(250);
            } catch { }
            // refocus
            target =
                document.querySelector('[data-content-editable-leaf="true"]') ||
                document.querySelector('.notion-page-content [contenteditable="true"]') ||
                target;
            target.click();
            target.focus();
            await sleep(120);
        }

        try {
            // Convert markdown to HTML for nicer Notion formatting
            const htmlContent = simpleMarkdownToHtml(markdownContent);

            const clipboardItem = new ClipboardItem({
                'text/html': new Blob([htmlContent], { type: 'text/html' }),
                'text/plain': new Blob([markdownContent], { type: 'text/plain' })
            });

            await navigator.clipboard.write([clipboardItem]);

            // Trigger paste
            target.focus();
            await sleep(60);

            // execCommand('paste') is often blocked; we still attempt it
            const pasted = document.execCommand('paste');
            if (!pasted) {
                // Dispatch paste event with DataTransfer (best effort)
                const dt = new DataTransfer();
                dt.setData('text/html', htmlContent);
                dt.setData('text/plain', markdownContent);

                const evt = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
                target.dispatchEvent(evt);
            }

            await sleep(350);
            return true;
        } catch (e) {
            Logger.warn('[CRIXEN][Notion] Clipboard insertion failed, fallback modal', e);
            showCopyModal(markdownContent);
            return false;
        }
    }

    function simpleMarkdownToHtml(markdown) {
        let html = String(markdown || '');

        // headers
        html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
        html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
        html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');

        // bold/italic
        html = html.replace(/\*\*(.*?)\*\*/gim, '<b>$1</b>');
        html = html.replace(/\*(.*?)\*/gim, '<i>$1</i>');

        // code blocks (basic)
        html = html.replace(/```([\s\S]*?)```/gim, '<pre><code>$1</code></pre>');

        // tables (basic github-like)
        html = html.replace(/\|(.+)\|\n\|([-:| ]+)\|\n((?:\|.*\|\n?)*)/g, (match, header, sep, body) => {
            const headers = header.split('|').filter((h) => h.trim()).map((h) => `<th>${h.trim()}</th>`).join('');
            const rows = body.trim().split('\n').map((row) => {
                const cells = row.split('|').filter((c) => c.trim() !== '').map((c) => `<td>${c.trim()}</td>`).join('');
                return `<tr>${cells}</tr>`;
            });
            return `<table><thead><tr>${headers}</tr></thead><tbody>${rows.join('')}</tbody></table>`;
        });

        // unordered lists
        html = html.replace(/^\s*[-*]\s+(.*)$/gim, '<li>$1</li>');
        html = html.replace(/(<li>.*<\/li>)/gim, '<ul>$1</ul>');
        html = html.replace(/<\/ul>\s*<ul>/gim, '');

        // line breaks
        html = html.replace(/\n/g, '<br>');
        return html;
    }

    function showCopyModal(content) {
        const existing = document.getElementById('crixen-copy-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'crixen-copy-modal';
        modal.style.cssText = `
      position: fixed;
      top: 50%; left: 50%;
      transform: translate(-50%, -50%);
      background: #111;
      border: 1px solid #333;
      border-radius: 12px;
      padding: 18px;
      z-index: 999999;
      max-width: 720px;
      width: min(720px, 92vw);
      max-height: 80vh;
      overflow: auto;
      box-shadow: 0 25px 50px -12px rgba(0,0,0,0.6);
    `;

        modal.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
        <h3 style="color:#fff;margin:0;font-size:15px;">Copy content manually</h3>
        <button id="crixen-close-modal" style="background:#222;border:none;color:#fff;padding:6px 10px;border-radius:8px;cursor:pointer;">✕</button>
      </div>
      <p style="color:#aaa;font-size:13px;margin:0 0 10px;">Clipboard write blocked. Click copy, then paste into Notion.</p>
      <textarea id="crixen-copy-content" readonly style="
        width:100%;height:320px;background:#0b0b0b;color:#ddd;
        border:1px solid #333;border-radius:10px;padding:12px;
        font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        font-size:12px;resize:none;
      "></textarea>
      <div style="display:flex;gap:10px;margin-top:12px;">
        <button id="crixen-copy-btn" style="
          flex:1;background:#fff;border:none;color:#000;
          padding:10px;border-radius:10px;cursor:pointer;font-weight:800;
        ">Copy</button>
      </div>
    `;

        document.body.appendChild(modal);

        const ta = modal.querySelector('#crixen-copy-content');
        ta.value = String(content || '');

        modal.querySelector('#crixen-close-modal').onclick = () => modal.remove();
        modal.querySelector('#crixen-copy-btn').onclick = async () => {
            try {
                await navigator.clipboard.writeText(String(content || ''));
                showToast('Copied. Paste into Notion.', 'success');
            } catch {
                ta.select();
                document.execCommand('copy');
                showToast('Copied. Paste into Notion.', 'success');
            }
        };
    }

    // ---------------------------
    // Strategy capture (your logic mostly preserved)
    // ---------------------------

    async function scrapeStrategies() {
        Logger.info('[CRIXEN][Notion] Strategy scrape');

        const selection = window.getSelection();
        let hasSelection = selection?.toString()?.trim().length > 0;
        let autoSelected = false;

        if (!hasSelection) {
            const pageContent = document.querySelector('.notion-page-content') || document.body;
            const range = document.createRange();
            range.selectNodeContents(pageContent);
            selection.removeAllRanges();
            selection.addRange(range);
            hasSelection = true;
            autoSelected = true;
            await sleep(80);
        }

        let clipboardText = '';

        try {
            const copyOk = document.execCommand('copy');
            if (!copyOk) throw new Error('copy failed');

            // Read clipboard
            // Note: navigator.clipboard.readText may be blocked. We try both.
            try {
                clipboardText = await navigator.clipboard.readText();
            } catch {
                // paste hack
                const ta = document.createElement('textarea');
                ta.style.position = 'fixed';
                ta.style.left = '-9999px';
                document.body.appendChild(ta);
                ta.focus();
                document.execCommand('paste');
                clipboardText = ta.value || '';
                ta.remove();
            }
        } catch (e) {
            Logger.warn('[CRIXEN][Notion] Clipboard scrape failed, returning empty', e);
            selection.removeAllRanges();
            return [];
        }

        selection.removeAllRanges();

        if (!clipboardText.trim()) return [];

        // If auto-selected and not tabular: single capture
        const isTabular = clipboardText.includes('\t');
        if (autoSelected && !isTabular) {
            return [{ name: 'Page Content', prompt: clipboardText.trim() }];
        }

        const strategies = [];
        const lines = clipboardText.split('\n');

        for (let i = 0; i < lines.length; i++) {
            const cols = lines[i].split('\t').map((c) => c.trim()).filter(Boolean);
            if (cols.length >= 2) {
                const name = cols[0];
                const prompt = cols.slice(1).sort((a, b) => b.length - a.length)[0];
                if (name && prompt && name.length < 120) strategies.push({ name, prompt });
            } else if (cols.length === 1 && cols[0].length > 20) {
                strategies.push({ name: `st${String(i + 1).padStart(2, '0')}`, prompt: cols[0] });
            }
        }

        return strategies;
    }

    // ---------------------------
    // UI bits
    // ---------------------------

    function createButton(text, onClick, iconSvg, variant = 'secondary', description = '') {
        const btn = document.createElement('div');
        btn.role = 'button';
        btn.className = 'crixen-notion-btn';
        btn.innerHTML = `
      <span style="display:flex;align-items:center;margin-right:6px;width:16px;height:16px;">${iconSvg}</span>
      <span style="font-size:14px;">${text}</span>
    `;

        Object.assign(btn.style, {
            display: 'inline-flex',
            alignItems: 'center',
            justifyContent: 'center',
            height: '28px',
            padding: '0 8px',
            borderRadius: '6px',
            fontSize: '14px',
            fontWeight: '500',
            cursor: 'pointer',
            userSelect: 'none',
            transition: 'background 0.1s ease',
            whiteSpace: 'nowrap',
            position: 'relative',
            overflow: 'visible',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            color: 'inherit',
            background: variant === 'primary' ? 'rgba(46, 170, 220, 0.15)' : 'transparent'
        });

        let tooltip = null;

        btn.onmouseenter = () => {
            btn.style.background = variant === 'primary'
                ? 'rgba(46, 170, 220, 0.22)'
                : 'rgba(55, 53, 47, 0.08)';

            if (description) {
                tooltip = document.createElement('div');
                tooltip.textContent = description;
                Object.assign(tooltip.style, {
                    position: 'absolute',
                    top: '115%',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    background: '#191919',
                    color: 'white',
                    padding: '4px 8px',
                    borderRadius: '6px',
                    fontSize: '11px',
                    whiteSpace: 'nowrap',
                    zIndex: '1000',
                    pointerEvents: 'none',
                    boxShadow: '0 4px 12px rgba(0,0,0,0.25)'
                });
                btn.appendChild(tooltip);
            }
        };

        btn.onmouseleave = () => {
            btn.style.background = variant === 'primary' ? 'rgba(46, 170, 220, 0.15)' : 'transparent';
            tooltip?.remove();
            tooltip = null;
        };

        btn.onmousedown = () => {
            btn.style.background = 'rgba(55, 53, 47, 0.16)';
        };
        btn.onmouseup = () => {
            btn.style.background = 'rgba(55, 53, 47, 0.08)';
        };

        btn.onclick = (e) => {
            e.stopPropagation();
            onClick();
        };

        return btn;
    }

    function showToast(message, type = 'info') {
        document.querySelectorAll('.crixen-toast').forEach((t) => t.remove());

        const toast = document.createElement('div');
        toast.className = 'crixen-toast';
        toast.innerText = message;

        const colors = {
            success: { bg: 'rgba(16, 185, 129, 0.95)', border: 'rgba(16, 185, 129, 0.5)' },
            error: { bg: 'rgba(239, 68, 68, 0.95)', border: 'rgba(239, 68, 68, 0.5)' },
            warning: { bg: 'rgba(245, 158, 11, 0.95)', border: 'rgba(245, 158, 11, 0.5)' },
            info: { bg: 'rgba(59, 130, 246, 0.95)', border: 'rgba(59, 130, 246, 0.5)' }
        };

        const color = colors[type] || colors.info;

        Object.assign(toast.style, {
            position: 'fixed',
            bottom: '80px',
            right: '20px',
            background: color.bg,
            color: 'white',
            border: `1px solid ${color.border}`,
            padding: '12px 16px',
            borderRadius: '10px',
            fontSize: '13px',
            fontWeight: '700',
            zIndex: '10000',
            boxShadow: '0 8px 28px rgba(0,0,0,0.25)',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
        });

        document.body.appendChild(toast);
        setTimeout(() => toast.remove(), 2800);
    }

    function showAuthPrompt() {
        const existing = document.querySelectorAll('.crixen-auth-prompt');
        existing.forEach((el) => el.remove());

        const toast = document.createElement('div');
        toast.className = 'crixen-auth-prompt';
        toast.innerHTML = `
      <div style="display:flex;align-items:center;gap:12px;">
        <span>Login required to use Crixen</span>
        <button id="crixen-notion-login-btn" style="
          background:white;color:#000;border:none;padding:6px 12px;border-radius:8px;
          font-weight:800;cursor:pointer;font-size:13px;
        ">Login</button>
      </div>
    `;

        Object.assign(toast.style, {
            position: 'fixed',
            bottom: '80px',
            right: '20px',
            background: 'rgba(20, 20, 20, 0.95)',
            border: '1px solid rgba(255, 255, 255, 0.2)',
            color: 'white',
            padding: '12px 16px',
            borderRadius: '10px',
            zIndex: '10000',
            fontFamily: '-apple-system, BlinkMacSystemFont, sans-serif',
            fontSize: '14px',
            boxShadow: '0 8px 28px rgba(0,0,0,0.35)'
        });

        document.body.appendChild(toast);

        toast.querySelector('#crixen-notion-login-btn')?.addEventListener('click', () => {
            window.open('https://crixen.xyz', '_blank');
            toast.remove();
        });

        setTimeout(() => toast.remove(), 9000);
    }

    // ---------------------------
    // Modal input UI (kept from your design, slightly simplified)
    // ---------------------------

    function createInputModal(title, questions, iconSvg) {
        return new Promise((resolve) => {
            const overlay = document.createElement('div');
            Object.assign(overlay.style, {
                position: 'fixed',
                top: '0',
                left: '0',
                width: '100%',
                height: '100%',
                background: 'rgba(0,0,0,0.6)',
                backdropFilter: 'blur(8px)',
                zIndex: '99999',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                opacity: '0',
                transition: 'opacity 0.25s ease'
            });

            const modal = document.createElement('div');
            Object.assign(modal.style, {
                width: '520px',
                maxWidth: '92vw',
                maxHeight: '85vh',
                overflowY: 'auto',
                background: 'rgba(20, 20, 20, 0.96)',
                border: '1px solid rgba(255, 255, 255, 0.10)',
                borderRadius: '16px',
                padding: '24px',
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.5)',
                transform: 'translateY(18px)',
                transition: 'transform 0.25s ease',
                fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
                color: '#fff'
            });

            const header = document.createElement('div');
            header.style.display = 'flex';
            header.style.alignItems = 'center';
            header.style.gap = '12px';
            header.style.marginBottom = '18px';

            if (iconSvg) {
                const icon = document.createElement('div');
                icon.innerHTML = iconSvg;
                Object.assign(icon.style, {
                    width: '34px',
                    height: '34px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    background: 'rgba(255,255,255,0.08)',
                    borderRadius: '10px'
                });
                header.appendChild(icon);
            }

            const h = document.createElement('h2');
            h.textContent = title;
            h.style.margin = '0';
            h.style.fontSize = '18px';
            h.style.fontWeight = '800';
            header.appendChild(h);

            modal.appendChild(header);

            const fields = {};

            for (const q of questions) {
                const wrap = document.createElement('div');
                wrap.style.marginBottom = '14px';

                const label = document.createElement('div');
                label.textContent = q.label + (q.required ? ' *' : '');
                Object.assign(label.style, {
                    fontSize: '12px',
                    fontWeight: '800',
                    opacity: '0.75',
                    letterSpacing: '0.4px',
                    textTransform: 'uppercase',
                    marginBottom: '8px'
                });
                wrap.appendChild(label);

                const base = {
                    width: '100%',
                    padding: '10px 12px',
                    borderRadius: '10px',
                    border: '1px solid rgba(255,255,255,0.14)',
                    color: '#fff',
                    background: 'rgba(255,255,255,0.06)',
                    fontSize: '14px',
                    outline: 'none'
                };

                let input;

                if (q.type === 'textarea') {
                    input = document.createElement('textarea');
                    input.rows = 4;
                    Object.assign(input.style, base, { resize: 'vertical', lineHeight: '1.4' });
                    input.getValue = () => input.value.trim();
                } else if (q.type === 'select') {
                    input = document.createElement('select');
                    Object.assign(input.style, base, { cursor: 'pointer' });
                    const first = document.createElement('option');
                    first.value = '';
                    first.textContent = 'Select...';
                    input.appendChild(first);
                    for (const opt of q.options || []) {
                        const o = document.createElement('option');
                        o.value = opt;
                        o.textContent = opt;
                        input.appendChild(o);
                    }
                    input.getValue = () => input.value.trim();
                } else if (q.type === 'multiselect') {
                    input = document.createElement('div');
                    input.style.display = 'flex';
                    input.style.flexWrap = 'wrap';
                    input.style.gap = '8px';

                    for (const opt of q.options || []) {
                        const chip = document.createElement('div');
                        chip.textContent = opt;
                        chip.dataset.selected = 'false';
                        Object.assign(chip.style, {
                            padding: '7px 10px',
                            borderRadius: '999px',
                            border: '1px solid rgba(255,255,255,0.14)',
                            background: 'rgba(255,255,255,0.05)',
                            cursor: 'pointer',
                            fontSize: '13px',
                            fontWeight: '700',
                            opacity: '0.9'
                        });

                        chip.onclick = () => {
                            const on = chip.dataset.selected === 'true';
                            chip.dataset.selected = on ? 'false' : 'true';
                            chip.style.background = on ? 'rgba(255,255,255,0.05)' : '#fff';
                            chip.style.color = on ? '#fff' : '#000';
                        };

                        input.appendChild(chip);
                    }

                    input.getValue = () =>
                        Array.from(input.children)
                            .filter((c) => c.dataset.selected === 'true')
                            .map((c) => c.textContent)
                            .join(', ');
                } else {
                    input = document.createElement('input');
                    input.type = 'text';
                    Object.assign(input.style, base);
                    input.getValue = () => input.value.trim();
                }

                fields[q.id] = input;
                wrap.appendChild(input);
                modal.appendChild(wrap);
            }

            const footer = document.createElement('div');
            footer.style.display = 'flex';
            footer.style.justifyContent = 'flex-end';
            footer.style.gap = '10px';
            footer.style.marginTop = '18px';

            const cancel = document.createElement('button');
            cancel.textContent = 'Cancel';
            Object.assign(cancel.style, {
                padding: '10px 14px',
                borderRadius: '10px',
                border: '1px solid rgba(255,255,255,0.14)',
                background: 'transparent',
                color: '#fff',
                cursor: 'pointer',
                fontWeight: '800'
            });

            const submit = document.createElement('button');
            submit.textContent = 'Generate';
            Object.assign(submit.style, {
                padding: '10px 14px',
                borderRadius: '10px',
                border: 'none',
                background: '#fff',
                color: '#000',
                cursor: 'pointer',
                fontWeight: '900'
            });

            cancel.onclick = () => close(null);
            submit.onclick = () => {
                const out = {};
                const missing = [];
                for (const q of questions) {
                    const v = fields[q.id].getValue();
                    if (q.required && !v) missing.push(q.label);
                    out[q.id] = v;
                }
                if (missing.length) {
                    alert('Please fill: ' + missing.join(', '));
                    return;
                }
                close(out);
            };

            footer.appendChild(cancel);
            footer.appendChild(submit);
            modal.appendChild(footer);

            overlay.appendChild(modal);
            document.body.appendChild(overlay);

            requestAnimationFrame(() => {
                overlay.style.opacity = '1';
                modal.style.transform = 'translateY(0)';
            });

            function close(result) {
                overlay.style.opacity = '0';
                modal.style.transform = 'translateY(18px)';
                setTimeout(() => {
                    overlay.remove();
                    resolve(result);
                }, 250);
            }
        });
    }

    // ---------------------------
    // Storage helpers
    // ---------------------------

    function storageGet(key) {
        return new Promise((resolve) => chrome.storage.local.get(key, resolve));
    }
    function storageSet(obj) {
        return new Promise((resolve) => chrome.storage.local.set(obj, resolve));
    }

    function sleep(ms) {
        return new Promise((r) => setTimeout(r, ms));
    }

    // ---------------------------
    // Message listener (kept)
    // ---------------------------

    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'scrapeNotionStrategies') {
            scrapeStrategies().then((strategies) => sendResponse({ success: true, strategies }));
            return true;
        }
        if (request.action === 'pushNotionReport') {
            // If you still call this legacy endpoint, we use new report builder.
            (async () => {
                const reportMd = await buildIndustryDailyReport(request.stats || {});
                const ok = await insertContentIntoNotion(reportMd, false);
                sendResponse({ success: ok, message: ok ? 'Report appended' : 'Insert failed' });
            })();
            return true;
        }
        if (request.action === 'checkNotionPage') {
            sendResponse({ isNotion: true, title: document.title });
        }
    });

    Logger.info('[CRIXEN][Notion] Initialized');
})();