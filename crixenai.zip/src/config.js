export const CONFIG = {
    API_URL: 'https://api.crixen.xyz/api/v1/ai/generate',
    NEAR_AI_ENDPOINT: 'https://cloud-api.near.ai/v1/chat/completions'
};
